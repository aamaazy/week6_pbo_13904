package Transportasi;
import java.util.Scanner;

import TransportasiAksi.TransportasiDemo;

public class Bicycle
{
    public static void main (String args[])
    {
        System.out.println("Ini Sepeda");
        /*Scanner input = new Scanner (System.in);

        int pilih;
        int jumlah;
        String nama;
        String notlp;
        String alamat;

        System.out.println("---------------- Program Pembelian Sepeda ---------------- \n");

        // Perintah Inputan Data Pembeli Sepeda
        System.out.println("A. Data Pembeli Sepeda");
        System.out.print("Masukan Nama Pembeli     = ");
        nama = input.nextLine();
        System.out.print("Masukan Nomor Telepon    = ");
        notlp = input.nextLine();
        System.out.print("Masukan Alamat Pembeli   = ");
        alamat = input.nextLine();

        // Daftar Stok Sepeda
        System.out.println("----------------------------------------------------------");
        System.out.println("B. Daftar Sepeda");
        System.out.println("No    Merk                Tipe                Harga");
        System.out.println("1     Polygon             Cascade 2           Rp 2.200.000");
        System.out.println("2     Polygon             Xtrada 6            Rp 6.200.000");
        System.out.println("3     United              Detroit 3.0         Rp 2.500.000");
        System.out.println("4     United              Detroit 7.1         Rp 6.000.000");
        System.out.println("5     Pacific             Aquila              Rp 4.400.000");
        System.out.println("6     Pacific             Fervent             Rp 7.295.000");
        System.out.println("----------------------------------------------------------");

        // Perintah Inputan 
        System.out.print("Masukan Nomor Sepeda Yang Ingin Dibeli  = ");
        pilih = input.nextInt();
        System.out.print("Masukan Jumlah Sepeda Yang Ingin Dibeli = ");
        jumlah = input.nextInt();

        // Percabangan Switch Case
        switch (pilih)
        {
            case 1:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Sepeda      = Polygon");
                System.out.println("Tipe Sepeda      = Cascade 2");
                System.out.println("Harga Sepeda     = Rp 2.200.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*2200000);
                break;

                case 2:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Sepeda      = Polygon");
                System.out.println("Tipe Sepeda      = Xtrada 6");
                System.out.println("Harga Sepeda     = Rp 6.200.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*6200000);
                break;

                case 3:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Sepeda      = United");
                System.out.println("Tipe Sepeda      = Detroit 3.0");
                System.out.println("Harga Sepeda     = Rp 2.500.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*2500000);
                break;

                case 4:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Sepeda      = United");
                System.out.println("Tipe Sepeda      = Detroit 7.1");
                System.out.println("Harga Sepeda     = Rp 6.000.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*6000000);
                break;

                case 5:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Sepeda      = Pacific");
                System.out.println("Tipe Sepeda      = Aquila");
                System.out.println("Harga Sepeda     = Rp 4.400.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*4400000);
                break;

                case 6:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Sepeda      = Pacific");
                System.out.println("Tipe Sepeda      = Fervent");
                System.out.println("Harga Sepeda     = Rp 7.295.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*7295000);
                break;

                default:
                System.out.println("Salah Inputan");
        }*/
    }
}