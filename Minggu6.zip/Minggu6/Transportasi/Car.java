package Transportasi;
import java.util.Scanner;

import TransportasiAksi.TransportasiDemo;


public class Car
{
    public static void main (String args[])
    {
        System.out.println("Ini Mobil");
        /*Scanner input = new Scanner (System.in);

        int pilih;
        int jumlah;
        String nama;
        String notlp;
        String alamat;

        System.out.println("----------------- Program Pembelian Mobil ----------------- \n");

        // Perintah Inputan Data Pembeli Mobil
        System.out.println("A. Data Pembeli Mobil");
        System.out.print("Masukan Nama Pembeli     = ");
        nama = input.nextLine();
        System.out.print("Masukan Nomor Telepon    = ");
        notlp = input.nextLine();
        System.out.print("Masukan Alamat Pembeli   = ");
        alamat = input.nextLine();

        // Daftar Stok Sepeda
        System.out.println("-------------------------------------------------------------");
        System.out.println("B. Daftar Mobil");
        System.out.println("No    Merk              Tipe                Harga");
        System.out.println("1     Honda             HRV                 Rp 375.000.000");
        System.out.println("2     Honda             City Hatchback      Rp 373.000.000");
        System.out.println("3     Hyundai           Palisade            Rp 855.000.000");
        System.out.println("4     Hyundai           Creta               Rp 408.000.000");
        System.out.println("5     Toyota            Innova Zenix        Rp 601.000.000");
        System.out.println("6     Toyota            Veloz               Rp 301.000.000");
        System.out.println("-------------------------------------------------------------");

        // Perintah Inputan 
        System.out.print("Masukan Nomor Mobil Yang Ingin Dibeli  = ");
        pilih = input.nextInt();
        System.out.print("Masukan Jumlah Mobil Yang Ingin Dibeli = ");
        jumlah = input.nextInt();

        // Percabangan Switch Case
        switch (pilih)
        {
            case 1:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Mobil       = Honda");
                System.out.println("Tipe Mobil       = HRV");
                System.out.println("Harga Per Unit   = Rp 375.000.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*375000000);
                break;

                case 2:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Mobil       = Honda");
                System.out.println("Tipe Mobil       = City Hatchback");
                System.out.println("Harga Per Unit   = Rp 373.000.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*373000000);
                break;

                case 3:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Mobil       = Hyundai");
                System.out.println("Tipe Mobil       = Palisade");
                System.out.println("Harga Per Unit   = Rp 855.000.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*855000000);
                break;

                case 4:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Mobil       = Hyundai");
                System.out.println("Tipe Mobil       = Creta");
                System.out.println("Harga Per Unit   = Rp 408.000.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*408000000);
                break;

                case 5:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Mobil       = Toyota");
                System.out.println("Tipe Mobil       = Innova Zenix");
                System.out.println("Harga Per Unit   = Rp 601.000.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*601000000);
                break;

                case 6:
                System.out.println("Nama Pembeli     = "+nama);
                System.out.println("Nomor Telepon    = "+notlp);
                System.out.println("Alamat Pembeli   = "+alamat);

                System.out.println("Merk Mobil       = Toyota");
                System.out.println("Tipe Mobil       = Veloz");
                System.out.println("Harga Per Unit   = Rp 301.000.000");

                System.out.println("Jumlah Pembelian = "+jumlah);
                System.out.println("Total Pembayaran = "+jumlah*301000000);
                break;

                default:
                System.out.println("Salah Inputan");
        }*/
    }
}